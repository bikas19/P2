package com.vastika.smd.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.vastika.smd.model.User;
import com.vastika.smd.repository.UserRepository;

public class UserServiceImpl implements UserService {

	@Autowired	
	private UserRepository userRepository; 
	
	@Override
	public void saveUserinfo(User user) {
		userRepository.saveUserinfo(user);
	}

}
