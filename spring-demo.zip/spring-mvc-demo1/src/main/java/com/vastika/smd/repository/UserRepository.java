package com.vastika.smd.repository;

import java.util.List;

import com.vastika.smd.model.User;

public interface UserRepository {
	
	void saveUserinfo(User user);
	
	List<User> getAllUserinfo();
	

}
