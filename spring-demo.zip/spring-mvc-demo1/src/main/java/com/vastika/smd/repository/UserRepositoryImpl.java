package com.vastika.smd.repository;

import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

import com.vastika.smd.model.User;
import com.vastika.smd.util.QueryUtil;

public class UserRepositoryImpl implements UserRepository {

	@Autowired
	private DataSource dataSource;

	@Override
	public void saveUserinfo(User user) {

		JdbcTemplate jdbcTemplate = new JdbcTemplate(dataSource);

		jdbcTemplate.update(QueryUtil.INSERT_SQL,
				new Object[] { user.getUserName(), user.getPassword(), user.getEmail(), user.getDob(),
						user.getVerificationType(), user.getHobbies(), user.getGender(), user.getMobileNo(),
						user.getAddress().getCityName(), user.getAddress().getCountryName() });

	}

	@Override
	public List<User> getAllUserinfo() {
		List<User> userliList = new ArrayList<>();

		return userliList;
	}

}
