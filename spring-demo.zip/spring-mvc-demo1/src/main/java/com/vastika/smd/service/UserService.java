package com.vastika.smd.service;

import com.vastika.smd.model.User;

public interface UserService {
	
	void saveUserinfo(User user);

}
