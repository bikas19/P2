package com.vastika.smd.util;

public class QueryUtil {
	
	public static final String INSERT_SQL = "insert into user_tbl(user_name, password, email, dob, verification_type, hobbies, gender, mobile_no, city_name, country_name)values(?,?,?,?,?,?,?,?,?,?)";
	public static final String LIST_SQL= "select * from user_tbl";

}
