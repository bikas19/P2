package com.vastika.smd.util;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.vastika.smd.model.Address;
import com.vastika.smd.model.User;

public class UserRowMapper implements RowMapper<User> {

	@Override
	public User mapRow(ResultSet rs, int rowNum) throws SQLException {
		User user = new User();
		user.setId(rs.getInt("id"));
		user.setUserName(rs.getNString("username"));
		user.setPassword(rs.getNString("password"));
		user.setDob(rs.getDate("dob"));
		user.setMobileNo(rs.getLong("mobile_no"));
		user.setHobbies(rs.getNString("hobbies"));
		user.setGender(rs.getNString("gender"));
		user.setEmail(rs.getNString("email"));
		user.setVerificationType(rs.getNString("verification_type"));
		
		Address address = new Address();
		address.setCityName(rs.getNString("city_name"));
		address.setCountryName(rs.getNString("country_name"));		
		
		return user;
	}

}
